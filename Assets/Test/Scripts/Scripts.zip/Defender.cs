using System.Collections;
using UnityEngine;

public class Defender : Unit
{
    private IMovable movementHandler;
    private DefenderData defenderData;
    private DefenderInteraction interactionHandler;
    private DefenderStateBehaviour stateBehaviour;
    [SerializeField] private GameObject detectionRangeObject;
    private Attacker target;

    public Attacker Target => target;

    public override void Initialize(UnitData data)
    {
        defenderData = data as DefenderData;
        if (defenderData == null)
        {
            Debug.LogError("Invalid DefenderData assigned!");
            return;
        }

        base.Initialize(data);
        movementHandler = new MovementHandler(transform, data.normalSpeed, Vector3.forward);
        interactionHandler = new DefenderInteraction(this);
        SetDetectionRadius();
    }

    public override void Activate()
    {
        base.Activate();
        stateBehaviour = new DefenderStateBehaviour(this, defenderData, detectionRangeObject);
        StartCoroutine(Tick());
    }
    private void SetDetectionRadius()
    {
        float fieldWidth = GetFieldWidth();
        float detectionRadius = fieldWidth * (defenderData.detectionRange / 100f);
        detectionRangeObject.transform.localScale = Vector3.one * detectionRadius;
    }

    private float GetFieldWidth()
    {
        Land field = FindObjectOfType<Land>();
        return field.GetComponent<Collider>().bounds.size.x;
    }

    IEnumerator Tick()
    {
        while (isActive)
        {
            movementHandler.Tick();
            stateBehaviour.UpdateState();
            yield return new WaitForSeconds(Time.deltaTime);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.TryGetComponent<IInteractable>(out IInteractable interactable))
        {
            interactable.Interact(this);
        }
    }

    void OnAttackerDetected(Attacker attacker)
    {
        stateBehaviour.OnAttackerDetected(attacker);
    }
    public void Move(Vector3 direction, float speed)
    {
        movementHandler.ChangeDirection(direction);
        movementHandler.ChangeSpeed(speed);
        movementHandler.Tick();
    }

    public void SetTarget(Attacker newTarget)
    {
        target = newTarget;
    }

    public void IgnoreCollisions(bool ignore)
    {
        GetComponent<Collider>().enabled = !ignore;
    }

    public float GetReturnSpeed()
    {
        return defenderData.returnSpeed;
    }

    public float GetDetectionRange()
    {
        return defenderData.detectionRange;
    }
}
