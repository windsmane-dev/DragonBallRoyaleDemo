using UnityEngine;

public class MovementHandler : IMovable
{
    private Transform unitTransform;
    private float speed;

    public MovementHandler(Transform transform, float initialSpeed, Vector3 initialDirection)
    {
        unitTransform = transform;
        speed = initialSpeed;
        ChangeDirection(initialDirection); // Ensures the unit is facing the correct direction initially
    }

    public void Tick()
    {
        unitTransform.position += unitTransform.forward * speed * Time.deltaTime;
    }

    public void ChangeSpeed(float newSpeed)
    {
        speed = newSpeed;
    }

    public void ChangeDirection(Vector3 newDirection)
    {
        if (newDirection != Vector3.zero)
        {
            Quaternion targetRotation = Quaternion.LookRotation(new Vector3(newDirection.x, 0f, newDirection.z).normalized);
            unitTransform.rotation = targetRotation;
        }
    }

    public void ResetRotation()
    {
        unitTransform.rotation = Quaternion.Euler(0f, unitTransform.rotation.eulerAngles.y, 0f);
    }
}
