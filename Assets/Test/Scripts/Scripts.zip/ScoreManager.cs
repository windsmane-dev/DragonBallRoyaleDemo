using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    protected int playerScore;
    protected int enemyScore;
    private void Start()
    {
        
    }

    private void OnDestroy()
    {
        
    }

   //void UpdateScore(int playerID)
   //{
   //    switch(playerID)
   //    {
   //        case 0:
   //            Debug.Log("draw");
   //            break;
   //        case 1:
   //            EventHolder.TriggerRequestTurnInfo((currentTurn) => {  });
   //            break;
   //        case 2:
   //            break;
   //    }
   //}
}
