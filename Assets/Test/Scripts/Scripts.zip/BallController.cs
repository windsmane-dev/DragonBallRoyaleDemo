using UnityEngine;

public class BallController : MonoBehaviour, IInteractable
{
    private bool isPickedUp = false;
    private Transform targetAttacker;
    private float passSpeed = 0f;

    private void OnEnable()
    {
        EventHolder.OnRequestBallStatus += ProvideBallStatus;
    }

    private void OnDisable()
    {
        EventHolder.OnRequestBallStatus -= ProvideBallStatus;
    }

    private void ProvideBallStatus(System.Action<Vector3, bool> callback)
    {
        callback(transform.position, isPickedUp);
    }

    public void PickUp(Transform newParent)
    {
        if (!isPickedUp)
        {
            isPickedUp = true;
            transform.SetParent(newParent);
            transform.localPosition = Vector3.zero;
            EventHolder.TriggerBallPickedUp();
        }
    }

    public void PassToAttacker(Transform attacker, float speed)
    {
        if (attacker == null)
        {
            Debug.LogError("No valid attacker to pass to.");
            return;
        }

        isPickedUp = false;
        targetAttacker = attacker;
        passSpeed = speed;
        transform.SetParent(null);
    }

    private void Update()
    {
        if (!isPickedUp && targetAttacker != null)
        {
            MoveTowardsTarget();
        }
    }

    private void MoveTowardsTarget()
    {
        transform.position = Vector3.MoveTowards(transform.position, targetAttacker.position, passSpeed * Time.deltaTime);

        if (Vector3.Distance(transform.position, targetAttacker.position) < 0.1f)
        {
            PickUp(targetAttacker);
            targetAttacker = null;
        }
    }

    public void Interact(Unit interactingUnit)
    {
        if (interactingUnit is Attacker attacker)
        {
            attacker.SendMessage("PickUpBall");
            PickUp(attacker.GetBallHoldPosition());
        }
    }
}
